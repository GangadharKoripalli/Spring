package com.virtusa.Controller;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@ComponentScan({"com.virtusa.Controller"})
public class TeluskoConfig 
{
	@Bean
  public InternalResourceViewResolver viewResolver()
  {
	  InternalResourceViewResolver  vr = new InternalResourceViewResolver(); // two things path and extention file type
	  vr.setPrefix("/");
	  vr.setSuffix(".jsp");
	  return vr;
  }
}
