package com.virtusa.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.service.AddService;



@Controller
public class AddController    //when i call this function 
{
	  @RequestMapping("/add")      // it comes here and do mapping whenever i call the add function
	  public ModelAndView add(@RequestParam("t1") int i,@RequestParam("t2") int j,HttpServletRequest request, HttpServletResponse response) // object creation 
	  {
		  
	//	  int i=Integer.parseInt(request.getParameter("t1"));
	//	  int j=Integer.parseInt(request.getParameter("t2"));
		//  int k=i+j;  // this i neeed to send to display page by using ModelAndView
		  
		  AddService as= new AddService(); // we have added service so that there  it wil add and we need fetch here
		  int k=as.add(i,j);
		 
		  ModelAndView mv=new ModelAndView(); //obect created , here we cn pass the data what we generated
		  
		 // 2 things we need to do to send the data
		  
		  mv.setViewName("Display"); // we need to set the viewname where we want to pass i.e file name
		  mv.addObject("result",k);// this is for what data u need to pass like add r sub or multip and for every object we have 2 things 
		  							// label and data ...here label is result and data is k
		  
		  return mv; // we should not pass string here so we need to use mv object which is ModelAndView....
		  				// so in public method which in add function use ModelAndview
	  }

}
